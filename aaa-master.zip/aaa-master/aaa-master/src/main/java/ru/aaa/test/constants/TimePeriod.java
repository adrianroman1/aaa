package ru.aaa.test.constants;

/**
 * @author adrian_rom�n
 */
public enum TimePeriod {
	
	SECONDS, MINUTES, HOURS

}
